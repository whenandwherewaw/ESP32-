C
^

Simple Line 
""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_line/lv_ex_line_1.png
  :alt: Line example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_line/lv_ex_line_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
